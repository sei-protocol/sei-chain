# Changelog for SeiContrib402

## Initial Commit: Complete Sovereign Architecture for Proof-of-Contribution on Sei

---

### contracts/ContributorWallet.sol
**Commit Message:**  
Add ContributorWallet.sol for immutable contributor sovereignty

**Description:**  
ContributorWallet.sol establishes the foundation for sovereign, immutable wallets tied to contributor identities.

- Immutable `owner` address per wallet  
- Withdrawals only permitted via authorized SeiKeyRegistry  
- Supports direct ETH/USDC reception via receive() fallback  
- Emits events for transparency on withdrawals and deposits  
- Withdrawals require live session validation from SeiKeyRegistry  

---

### contracts/SeiKey.sol
**Commit Message:**  
Add SeiKey.sol for ephemeral contributor session control

**Description:**  
SeiKey.sol introduces ephemeral session management for contributor wallets.

- Maps contributor addresses to ephemeral session hashes  
- Allows creation and revocation of sessions  
- Ensures withdrawals require live, valid sessions  
- Implements on-chain proof of active contributor state  

---

### contracts/SeiContribRouter.sol
**Commit Message:**  
Add SeiContribRouter.sol for automated contributor payment routing

**Description:**  
SeiContribRouter.sol implements routing for contributor payments.

- Deploys ContributorWallet contracts per contributor  
- Maps contributor addresses to wallet addresses  
- Routes payments securely via router  
- Integrates directly with SeiKey validation  

---

### scripts/deploy_wallet.ts
**Commit Message:**  
Add deploy_wallet.ts for ContributorWallet deployment simulation

**Description:**  
Mock script simulating ContributorWallet deployment via SeiContribRouter.

---

### scripts/test_payment.ts
**Commit Message:**  
Add test_payment.ts for simulated payment routing example

**Description:**  
Mock script simulating payment flow through SeiContribRouter.

---

### typescript/gitbot_trigger.ts
**Commit Message:**  
Add gitbot_trigger.ts for simulated GitHub contribution trigger

**Description:**  
Simulates GitBot-style flow from commit verification to wallet creation.

---

### typescript/seiKeySession.ts
**Commit Message:**  
Add seiKeySession.ts for mock SeiKey session generation

**Description:**  
Simulates entropy-based ephemeral session key generation for SeiKey.

---

### README.md
**Commit Message:**  
Add README.md with full architecture overview

**Description:**  
README.md outlines the architecture, purpose, and licensing terms of SeiContrib402.

- Explains sovereign contributor payment protocol  
- Details components and flow  
- Clarifies $25M offer to Sei Protocol  

---

### LICENSE.md
**Commit Message:**  
Add LICENSE.md with MIT + Sei exclusive $25M acquisition terms

**Description:**  
MIT License with special $25M exclusive buyout terms for Sei Protocol. Retains sovereignty until purchase.

---

