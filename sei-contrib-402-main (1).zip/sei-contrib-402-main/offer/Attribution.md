This work, SeiContrib402 and all included components, was authored by Jon Sanders on 7/21/2025.

All intellectual property rights, architecture, contracts, and documentation are the sole creation of the undersigned.

No part of this repository has been copied, forked, or derived from other proprietary systems. This architecture is novel and was authored with the intent of sovereign contributor payments tied to provable identity on the Sei blockchain.

Until purchased, all rights are reserved by the creator.

Signed,
Jon Sanders
Date: 7/21/2025
