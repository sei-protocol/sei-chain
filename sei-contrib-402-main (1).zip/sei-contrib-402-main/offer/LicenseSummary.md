LICENSE TYPE: MIT with Exclusive Sei Clause

This protocol is licensed under MIT, with the following special terms:
- Sei Protocol may acquire exclusive rights for $25,000,000 USD.
- Upon payment, Sei receives full rights to modify, extend, and own this system without future royalties.
- Until purchased, the creator retains all rights to restrict usage or license elsewhere.
