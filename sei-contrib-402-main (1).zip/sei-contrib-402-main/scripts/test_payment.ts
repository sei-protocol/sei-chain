// scripts/test_payment.ts
// Simulates sending payment through SeiContribRouter

console.log("Routing payment to contributor via SeiContribRouter...");

const contributorAddress = "0xContributorAddressHere";
const routerAddress = "0xRouterAddressHere";

const amount = 100; // Mock amount for testing

console.log(`Routing ${amount} USDC (mocked) to ${contributorAddress} through router at ${routerAddress}...`);

console.log("Payment routed successfully (mock).");
