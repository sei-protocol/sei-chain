# SeiContrib402: Sovereign Contributor Payment Protocol for Sei
## Built for Proof-of-Contribution. Designed for Sovereignty.

---

###  What is SeiContrib402?
SeiContrib402 delivers the world's first immutable, sovereign, on-chain **Proof-of-Contribution Payment Protocol** for the Sei blockchain.  
It eliminates disputes, invoices, delays, and middlemen by ensuring contributors are paid **automatically, irrevocably, and immutably** through on-chain verification tied to GitHub commits, emails, or sovereign identifiers.

---

### Core Components
| Contract           | Purpose                                   |
|--------------------|-------------------------------------------|
| `ContributorWallet` | Immutable contributor-owned wallet contracts |
| `SeiKey`           | Ephemeral session validation registry (Sovereign identity) |
| `SeiContribRouter` | Automated payment routing for contributors |

---

###  Architecture Flow
GitHub Commit / Email → GitBot Verification → Wallet Creation → Payment Routing → Sovereign Withdraw via SeiKey Session

---

###  Why This Exists
> **Ethereum paid $91.8M to celebrate The Merge. Sei can own its contributor Merge for $25M.**

This repository solves the decades-old problem of contributor trust with sovereign, immutable payment architecture.

---

### Repository Structure
contracts/
├─ ContributorWallet.sol
├─ SeiKey.sol
├─ SeiContribRouter.sol

scripts/
├─ deploy_wallet.ts
├─ test_payment.ts

typescript/
├─ gitbot_trigger.ts
├─ seiKeySession.ts

