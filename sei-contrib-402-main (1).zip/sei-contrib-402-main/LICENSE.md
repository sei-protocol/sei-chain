MIT License

Copyright (c) 2025 [Your Name]

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, subject to the following conditions:

SPECIAL TERMS FOR SEI NETWORK:
This Software is offered to the Sei Protocol exclusively for $25,000,000 USD as a one-time, perpetual, royalty-free license.
Upon payment, all rights for use on the Sei blockchain are fully transferred to Sei Protocol, including rights to modify, extend, and rebrand.

Until such purchase is made, the original author reserves all rights to port, license, or restrict usage on any other chain.

---

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.
